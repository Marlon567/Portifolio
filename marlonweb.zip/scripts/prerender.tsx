import React from "react";
import { renderToString } from "react-dom/server";
import { readFileSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";
import App from "../client/src/App";
import { site } from "../client/src/lib/site";

const path = resolve("client/index.html");
let html = readFileSync(path, "utf8");
const markup = renderToString(<App />);
html = html.replace(
  /<div id="root">[\s\S]*?<\/div>\s*<script src="\/api\/platform\/config.js"><\/script>/,
  `<div id="root">${markup}</div>\n    <script src="/api/platform/config.js"></script>`
);
// Canonical and sharing-origin tags are emitted only after a real public domain is configured.
html = html
  .replace(/\s*<link rel="canonical"[^>]*>/g, "")
  .replace(/\s*<meta property="og:url"[^>]*>/g, "");
if (site.publicOrigin) {
  const origin = new URL(site.publicOrigin).origin;
  html = html.replace(
    "</head>",
    `<link rel="canonical" href="${origin}/" />\n<meta property="og:url" content="${origin}/" />\n</head>`
  );
}
writeFileSync(path, html);
console.log(
  "HTML inicial pré-renderizado com as seções públicas do portfólio."
);
