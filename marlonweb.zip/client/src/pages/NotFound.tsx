import { ArrowLeft, Code2 } from "lucide-react";
import { useEffect } from "react";

export default function NotFound() {
  useEffect(() => {
    const robots = document.createElement("meta");
    robots.name = "robots";
    robots.content = "noindex";
    document.head.appendChild(robots);
    document.title = "Página não encontrada | Marlon Prado";
    if (window.location.pathname.replace(/\/$/, "") !== "/404")
      window.location.replace("/404");
    return () => robots.remove();
  }, []);
  return (
    <main className="min-h-screen flex items-center justify-center px-6 text-center">
      <div className="max-w-md">
        <Code2 className="mx-auto mb-6 text-blue-400" size={42} />
        <span className="eyebrow">ERRO 404</span>
        <h1 className="text-3xl mb-4">Essa página não foi encontrada.</h1>
        <p className="text-slate-400 mb-8">
          O endereço pode ter mudado ou não existir. Vamos voltar para o
          portfólio?
        </p>
        <a className="button button-primary" href="/">
          <ArrowLeft size={17} />
          Voltar ao início
        </a>
      </div>
    </main>
  );
}
