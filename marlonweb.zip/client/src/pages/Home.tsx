import { useEffect, useState } from "react";
import {
  ArrowDown,
  ArrowRight,
  ArrowUpRight,
  Braces,
  Check,
  CheckCircle2,
  Code2,
  Dumbbell,
  Gauge,
  Globe2,
  Layers3,
  Mail,
  Menu,
  MessageCircle,
  MonitorSmartphone,
  MousePointer2,
  PenTool,
  Rocket,
  Scissors,
  Search,
  ShieldCheck,
  Sparkles,
  UtensilsCrossed,
  Wrench,
  X,
} from "lucide-react";
import ProjectGallery from "../components/portfolio/ProjectGallery";
import ContactForm from "../components/portfolio/ContactForm";
import { navigation, site } from "../lib/site";

const services = [
  {
    title: "Sites institucionais",
    service: "Site institucional",
    icon: Globe2,
    description:
      "Uma presença digital à altura da sua empresa. Apresente sua marca, seus serviços e o que faz você ser diferente.",
    tag: "PRESENÇA DIGITAL",
  },
  {
    title: "Landing pages",
    service: "Landing page",
    icon: MousePointer2,
    description:
      "Páginas com uma direção clara: transformar atenção em ação. Estrutura estratégica para sua oferta ou campanha.",
    tag: "FOCO EM CONVERSÃO",
  },
  {
    title: "Sites para restaurantes",
    service: "Site para restaurante",
    icon: UtensilsCrossed,
    description:
      "Dê um gostinho da experiência. Cardápio, ambiente, localização e contato reunidos em um site convidativo.",
    tag: "GASTRONOMIA",
  },
  {
    title: "Barbearias e salões",
    service: "Site para barbearia ou salão",
    icon: Scissors,
    description:
      "Seu estilo também merece estar online. Mostre serviços, equipe e facilite o contato para agendamentos.",
    tag: "BELEZA & ESTILO",
  },
  {
    title: "Sites para academias",
    service: "Site para academia",
    icon: Dumbbell,
    description:
      "Apresente modalidades, estrutura e planos com uma experiência que motiva o visitante a dar o primeiro passo.",
    tag: "SAÚDE & MOVIMENTO",
  },
  {
    title: "Portfólios profissionais",
    service: "Portfólio profissional",
    icon: PenTool,
    description:
      "Seu trabalho em destaque. Uma vitrine personalizada para valorizar seus projetos e sua trajetória profissional.",
    tag: "MARCA PESSOAL",
  },
  {
    title: "Redesign de sites",
    service: "Redesign de site",
    icon: Layers3,
    description:
      "Um novo olhar para seu site atual. Atualize o visual, melhore a navegação e torne a experiência mais relevante.",
    tag: "NOVA EXPERIÊNCIA",
  },
  {
    title: "Manutenção e otimização",
    service: "Manutenção e otimização",
    icon: Wrench,
    description:
      "Seu site bem cuidado. Atualizações, ajustes de desempenho e melhorias para acompanhar seu negócio.",
    tag: "EVOLUÇÃO CONTÍNUA",
  },
];

const technologies = [
  {
    label: "HTML5",
    symbol: "5",
    color: "#f57641",
    description: "Estrutura semântica",
  },
  {
    label: "CSS3",
    symbol: "3",
    color: "#58a8ff",
    description: "Design e responsividade",
  },
  {
    label: "JavaScript",
    symbol: "JS",
    color: "#efd65b",
    description: "Interações inteligentes",
  },
  {
    label: "React",
    symbol: "⚛",
    color: "#70d7f5",
    description: "Interfaces dinâmicas",
  },
  {
    label: "TypeScript",
    symbol: "TS",
    color: "#66a9f3",
    description: "Código consistente",
  },
  {
    label: "Tailwind CSS",
    symbol: "≈",
    color: "#6cdbf6",
    description: "Visual sob medida",
  },
];

export function Brand({ footer = false }: { footer?: boolean }) {
  return (
    <a
      className={`brand ${footer ? "brand-footer" : ""}`}
      href="#inicio"
      aria-label={`${site.name} — voltar ao início`}
    >
      <span className="brand-mark" aria-hidden="true">
        <svg width="24" height="22" viewBox="0 0 24 22" fill="none">
          <path
            d="M1 17V5L7 11L12 5V17M16 17V5H21V11H16"
            stroke="currentColor"
            strokeWidth="2.2"
            strokeLinejoin="round"
          />
        </svg>
      </span>
      <span>
        <b>
          marlon<span className="brand-last">prado</span>
          <i>.</i>
        </b>
        <small>DESENVOLVEDOR WEB</small>
      </span>
    </a>
  );
}

function SectionTitle({
  eyebrow,
  title,
  emphasis,
  description,
}: {
  eyebrow: string;
  title: string;
  emphasis?: string;
  description?: string;
}) {
  return (
    <div className="section-title">
      <span className="eyebrow">
        <span />
        {eyebrow}
      </span>
      <h2>
        {title}
        {emphasis && (
          <>
            <br />
            <span>{emphasis}</span>
          </>
        )}
      </h2>
      {description && <p>{description}</p>}
    </div>
  );
}

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [active, setActive] = useState("inicio");
  const [selectedService, setSelectedService] = useState("");
  const [faqOpen, setFaqOpen] = useState<number | null>(0);

  useEffect(() => {
    if (!("IntersectionObserver" in window)) return;
    const observer = new IntersectionObserver(
      entries => {
        entries.forEach(entry => {
          if (entry.isIntersecting) setActive(entry.target.id);
        });
      },
      { rootMargin: "-20% 0px -60% 0px" }
    );
    navigation.forEach(([id]) => {
      const element = document.getElementById(id);
      if (element) observer.observe(element);
    });
    return () => observer.disconnect();
  }, []);

  function quote(service = "") {
    setSelectedService(service);
    setMenuOpen(false);
    document
      .getElementById("contato")
      ?.scrollIntoView({
        behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches
          ? "auto"
          : "smooth",
      });
  }

  const faqs = [
    [
      "Como funciona o orçamento?",
      "Primeiro, entendo seu negócio, seus objetivos e o que o site precisa fazer. Com esse escopo definido, preparo uma proposta personalizada. O valor depende das páginas, funcionalidades e integrações necessárias.",
    ],
    [
      "Meu site vai funcionar no celular?",
      "Sim. O desenvolvimento considera celular, tablet e desktop desde o início, com layouts adaptáveis, navegação simples e cuidado com a legibilidade.",
    ],
    [
      "Qual é o prazo para criar um site?",
      "O prazo é combinado na proposta, após definir o escopo. A complexidade do projeto, integrações e a disponibilidade de textos e imagens influenciam o cronograma.",
    ],
    [
      "Você pode melhorar um site que já existe?",
      "Sim. Posso avaliar a estrutura atual e propor um redesign, ajustes de desempenho ou manutenção. A viabilidade e as melhorias são definidas após uma análise do site.",
    ],
  ];

  return (
    <>
      <a className="skip-link" href="#conteudo">
        Pular para o conteúdo
      </a>
      <header className="site-header">
        <div className="header-inner">
          <Brand />
          <nav className="desktop-nav" aria-label="Navegação principal">
            {navigation.map(([id, label]) => (
              <a
                className={active === id ? "active" : ""}
                key={id}
                href={`#${id}`}
                aria-current={active === id ? "location" : undefined}
              >
                {label}
              </a>
            ))}
          </nav>
          <button
            className="button button-primary header-quote"
            onClick={() => quote()}
          >
            Solicitar orçamento <ArrowUpRight size={15} />
          </button>
          <button
            className="menu-toggle"
            aria-label={menuOpen ? "Fechar menu" : "Abrir menu"}
            aria-expanded={menuOpen}
            aria-controls={menuOpen ? "mobile-menu" : undefined}
            onClick={() => setMenuOpen(!menuOpen)}
          >
            {menuOpen ? <X /> : <Menu />}
          </button>
        </div>
        {menuOpen && (
          <nav
            className="mobile-nav"
            id="mobile-menu"
            aria-label="Navegação móvel"
          >
            {navigation.map(([id, label]) => (
              <a key={id} href={`#${id}`} onClick={() => setMenuOpen(false)}>
                {label}
                <ArrowUpRight size={17} />
              </a>
            ))}
            <button className="button button-primary" onClick={() => quote()}>
              Solicitar orçamento <ArrowUpRight size={16} />
            </button>
          </nav>
        )}
      </header>

      <main id="conteudo">
        <section className="hero" id="inicio">
          <div className="hero-grid" aria-hidden="true" />
          <div className="hero-glow" aria-hidden="true" />
          <div className="container hero-inner">
            <div className="hero-copy">
              <span className="availability">
                <span />
                DESIGN COM PROPÓSITO. CÓDIGO COM PRECISÃO.
              </span>
              <h1>
                Transformo ideias <br />
                em{" "}
                <span>
                  experiências
                  <br className="desktop-break" /> digitais.
                </span>
              </h1>
              <p>
                Desenvolvo sites modernos, rápidos e estratégicos para empresas
                que desejam crescer e se destacar na internet.
              </p>
              <div className="hero-actions">
                <a className="button button-primary" href="#portfolio">
                  Conhecer meus projetos <ArrowUpRight size={18} />
                </a>
                <button
                  className="button button-outline"
                  onClick={() => quote()}
                >
                  Solicitar um orçamento <ArrowRight size={17} />
                </button>
              </div>
              <div className="hero-promises">
                <span>
                  <CheckCircle2 size={15} />
                  Design personalizado
                </span>
                <span>
                  <CheckCircle2 size={15} />
                  100% responsivo
                </span>
                <span>
                  <CheckCircle2 size={15} />
                  Foco no seu negócio
                </span>
              </div>
            </div>
            <div className="hero-visual">
              <div className="hero-orbit orbit-one" aria-hidden="true" />
              <div className="hero-orbit orbit-two" aria-hidden="true" />
              <div className="hero-image-wrap">
                <img
                  src={site.heroImage}
                  alt="Ilustração de um notebook exibindo um site profissional, com iluminação azul tecnológica"
                  width="1536"
                  height="864"
                  fetchPriority="high"
                />
              </div>
              <div className="floating-card code-card">
                <span className="float-icon">
                  <Code2 size={19} />
                </span>
                <div>
                  <b>Feito para o seu negócio</b>
                  <small>Design + estratégia + código</small>
                </div>
                <span className="card-dots">
                  <i />
                  <i />
                  <i />
                </span>
              </div>
              <div className="floating-card responsive-card">
                <span className="float-icon">
                  <MonitorSmartphone size={20} />
                </span>
                <div>
                  <b>Experiência em cada tela</b>
                  <small>Desktop, tablet e mobile</small>
                </div>
                <span className="small-check">
                  <Check size={12} />
                </span>
              </div>
              <span className="visual-caption">
                <span />
                &lt; ideias que ganham vida /&gt;
              </span>
            </div>
          </div>
          <div className="container hero-bottom">
            <a href="#sobre">
              Role para explorar <ArrowDown size={15} />
            </a>
            <span>ESTRATÉGIA. DESIGN. DESENVOLVIMENTO.</span>
          </div>
        </section>

        <div className="benefit-strip">
          <div className="container benefit-inner">
            <span className="benefit-intro">
              Mais do que um site.
              <br />
              <b>Uma presença que faz sentido.</b>
            </span>
            <div>
              <MonitorSmartphone />
              <span>Design responsivo</span>
            </div>
            <div>
              <Gauge />
              <span>Performance</span>
            </div>
            <div>
              <Search />
              <span>Boas práticas de SEO</span>
            </div>
            <div>
              <ShieldCheck />
              <span>Código bem estruturado</span>
            </div>
          </div>
        </div>

        <section className="section about-section" id="sobre">
          <div className="container about-layout">
            <div className="profile-composition">
              <div className="profile-frame">
                <span className="profile-top">POR TRÁS DO CÓDIGO</span>
                {site.profilePhoto ? (
                  <img
                    src={site.profilePhoto}
                    alt={`Foto de ${site.name}`}
                    width="480"
                    height="560"
                    loading="lazy"
                  />
                ) : (
                  <div className="profile-placeholder">
                    <span className="profile-corner corner-a" />
                    <span className="profile-corner corner-b" />
                    <span className="profile-initials">
                      MP<span>.</span>
                    </span>
                    <span className="profile-caption">
                      Espaço para sua foto de perfil
                    </span>
                  </div>
                )}
                <div className="profile-meta">
                  <b>{site.name}</b>
                  <span>DESENVOLVEDOR WEB FREELANCER</span>
                </div>
              </div>
              <div className="profile-tag">
                <span className="float-icon">
                  <Braces size={21} />
                </span>
                <div>
                  <b>Do conceito ao código.</b>
                  <small>Cada detalhe tem uma intenção.</small>
                </div>
              </div>
              <span className="profile-vertical">
                PENSADO PARA PESSOAS. CONSTRUÍDO COM TECNOLOGIA.
              </span>
            </div>
            <div className="about-copy">
              <SectionTitle
                eyebrow="SOBRE MIM"
                title="Tecnologia que aproxima."
                emphasis="Design que conecta."
              />
              <p className="about-lead">
                Sou desenvolvedor web apaixonado por tecnologia e criação de
                experiências digitais. Meu objetivo é ajudar empresas e
                empreendedores a fortalecerem sua presença online por meio de
                sites modernos, funcionais e personalizados.
              </p>
              <p>
                Combino um olhar cuidadoso para o design com desenvolvimento
                organizado. Cada projeto começa entendendo seu negócio e termina
                com uma experiência que comunica sua essência.
              </p>
              <div className="skill-list">
                <span>
                  <Check />
                  Interfaces modernas
                </span>
                <span>
                  <Check />
                  Desenvolvimento responsivo
                </span>
                <span>
                  <Check />
                  Performance e usabilidade
                </span>
                <span>
                  <Check />
                  Comunicação clara
                </span>
              </div>
              <button className="text-link" onClick={() => quote()}>
                Vamos conversar sobre seu projeto <ArrowUpRight size={18} />
              </button>
            </div>
          </div>
        </section>

        <section className="section services-section" id="servicos">
          <div className="container">
            <div className="section-heading-row">
              <SectionTitle
                eyebrow="O QUE POSSO FAZER POR VOCÊ"
                title="O site certo para"
                emphasis="o próximo passo do seu negócio."
              />
              <p className="section-aside">
                Soluções personalizadas para quem quer sair do comum e construir
                uma presença digital profissional.
              </p>
            </div>
            <div className="service-grid">
              {services.map((service, index) => (
                <article className="service-card" key={service.title}>
                  <div className="service-card-top">
                    <span className="service-icon">
                      <service.icon size={23} strokeWidth={1.6} />
                    </span>
                    <span className="service-number">0{index + 1}</span>
                  </div>
                  <span className="service-tag">{service.tag}</span>
                  <h3>{service.title}</h3>
                  <p>{service.description}</p>
                  <button
                    onClick={() => quote(service.service)}
                    className="service-cta"
                  >
                    Solicitar orçamento <ArrowUpRight size={17} />
                  </button>
                </article>
              ))}
            </div>
            <div className="services-note">
              <Sparkles size={17} />
              <p>
                Tem uma ideia diferente?{" "}
                <button onClick={() => quote("Quero uma orientação")}>
                  Vamos encontrar a solução ideal.
                </button>
              </p>
            </div>
          </div>
        </section>

        <section className="section portfolio-section" id="portfolio">
          <div className="container">
            <div className="section-heading-row">
              <SectionTitle
                eyebrow="PORTFÓLIO"
                title="Ideias que saem do papel."
                emphasis="Experiências que se destacam."
              />
              <p className="section-aside">
                Explore possibilidades para diferentes negócios. Cada conceito
                revela um jeito de unir estética, clareza e estratégia.
              </p>
            </div>
            <ProjectGallery onQuote={quote} />
            <p className="portfolio-disclaimer">
              <span />
              Projetos-conceito para demonstração visual. Não representam
              clientes ou resultados reais.
            </p>
          </div>
        </section>

        <section className="section technology-section" id="tecnologias">
          <div className="container">
            <div className="technology-heading">
              <SectionTitle
                eyebrow="MINHA CAIXA DE FERRAMENTAS"
                title="Boas ideias merecem"
                emphasis="uma base sólida."
                description="Tecnologias modernas, escolhidas de acordo com o que o seu projeto realmente precisa."
              />
              <span className="tech-code" aria-hidden="true">
                &lt;/&gt;
              </span>
            </div>
            <div className="tech-grid">
              {technologies.map(tech => (
                <div className="tech-card" key={tech.label}>
                  <span
                    className={`tech-symbol ${tech.label === "React" ? "react-symbol" : ""}`}
                    style={{ color: tech.color }}
                  >
                    {tech.symbol}
                  </span>
                  <h3>{tech.label}</h3>
                  <p>{tech.description}</p>
                </div>
              ))}
            </div>
            <div className="technology-foot">
              <Code2 size={19} />
              <p>
                Sem soluções engessadas.{" "}
                <b>A tecnologia se adapta ao projeto, não o contrário.</b>
              </p>
            </div>
          </div>
        </section>

        <section className="section process-section">
          <div className="container">
            <div className="section-heading-row">
              <SectionTitle
                eyebrow="DO PRIMEIRO CONTATO AO LANÇAMENTO"
                title="Um processo claro."
                emphasis="Um projeto bem cuidado."
              />
              <p className="section-aside">
                Você acompanha cada etapa. Sem complicação, com colaboração e
                atenção aos detalhes.
              </p>
            </div>
            <div className="process-track">
              {[
                {
                  number: "01",
                  title: "Entender",
                  text: "Conversamos sobre sua marca, seu público e o que você quer alcançar com o site.",
                  icon: MessageCircle,
                },
                {
                  number: "02",
                  title: "Planejar & criar",
                  text: "Definimos a estrutura e o visual para transformar a estratégia em uma experiência.",
                  icon: PenTool,
                },
                {
                  number: "03",
                  title: "Desenvolver",
                  text: "Construo um site responsivo, com cuidado no código, na navegação e na performance.",
                  icon: Code2,
                },
                {
                  number: "04",
                  title: "Colocar no ar",
                  text: "Revisamos os detalhes e preparamos o lançamento, com orientação para os próximos passos.",
                  icon: Rocket,
                },
              ].map(step => (
                <article className="process-step" key={step.number}>
                  <div className="process-top">
                    <span>{step.number}</span>
                    <step.icon size={20} />
                  </div>
                  <h3>{step.title}</h3>
                  <p>{step.text}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="section faq-section">
          <div className="container faq-layout">
            <SectionTitle
              eyebrow="SEM DÚVIDAS PELO CAMINHO"
              title="Antes de começar,"
              emphasis="vamos esclarecer."
              description="Algumas respostas para ajudar você a dar o próximo passo com confiança."
            />
            <div className="faq-list">
              {faqs.map(([question, answer], index) => (
                <div
                  className={`faq-item ${faqOpen === index ? "is-open" : ""}`}
                  key={question}
                >
                  <h3>
                    <button
                      aria-expanded={faqOpen === index}
                      aria-controls={`faq-${index}`}
                      onClick={() =>
                        setFaqOpen(faqOpen === index ? null : index)
                      }
                    >
                      {question}
                      <span>{faqOpen === index ? "−" : "+"}</span>
                    </button>
                  </h3>
                  <div id={`faq-${index}`} hidden={faqOpen !== index}>
                    <p>{answer}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="section contact-section" id="contato">
          <div className="contact-glow" aria-hidden="true" />
          <div className="container contact-layout">
            <div className="contact-copy">
              <span className="eyebrow">
                <span />
                VAMOS CONSTRUIR ALGO JUNTOS
              </span>
              <h2>
                Seu próximo
                <br />
                grande passo
                <br />
                <span>começa aqui.</span>
              </h2>
              <p>
                Tem uma ideia, um negócio ou um site que precisa evoluir? Me
                conte o que você imagina. Vamos encontrar o caminho para
                colocá-lo em prática.
              </p>
              <div className="contact-channels">
                {site.email ? (
                  <a href={`mailto:${site.email}`}>
                    <span className="channel-icon">
                      <Mail size={19} />
                    </span>
                    <div>
                      <small>E-MAIL PROFISSIONAL</small>
                      <b>{site.email}</b>
                    </div>
                    <ArrowUpRight size={17} />
                  </a>
                ) : (
                  <div className="unconfigured-channel">
                    <span className="channel-icon">
                      <Mail size={19} />
                    </span>
                    <div>
                      <small>E-MAIL PROFISSIONAL</small>
                      <b>Contato a configurar</b>
                    </div>
                  </div>
                )}
                {site.whatsapp ? (
                  <a
                    href={`https://wa.me/${site.whatsapp}`}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <span className="channel-icon">
                      <MessageCircle size={19} />
                    </span>
                    <div>
                      <small>WHATSAPP</small>
                      <b>{site.whatsappDisplay || "Iniciar uma conversa"}</b>
                    </div>
                    <ArrowUpRight size={17} />
                  </a>
                ) : (
                  <div className="unconfigured-channel">
                    <span className="channel-icon">
                      <MessageCircle size={19} />
                    </span>
                    <div>
                      <small>WHATSAPP</small>
                      <b>Número a configurar</b>
                    </div>
                  </div>
                )}
              </div>
              <p className="contact-note">
                <ShieldCheck size={15} />
                Sem compromisso. Primeiro, entendemos sua ideia.
              </p>
            </div>
            <ContactForm selectedService={selectedService} />
          </div>
        </section>
      </main>
      <footer className="site-footer">
        <div className="container footer-main">
          <Brand footer />
          <p>
            Sites que conectam sua marca
            <br />
            ao que vem a seguir.
          </p>
          <a className="back-top" href="#inicio">
            Voltar ao topo <ArrowUpRight size={17} />
          </a>
        </div>
        <div className="container footer-bottom">
          <span>
            © {new Date().getFullYear()} {site.name}. Todos os direitos
            reservados.
          </span>
          <span>Design com intenção. Código com cuidado.</span>
        </div>
      </footer>
    </>
  );
}
