export const site = {
  name: "Marlon Prado",
  role: "Desenvolvedor web freelancer",
  email: "marlonprado2001@gmail.com",
  whatsapp: "5516996262395", // Destino do link com DDI e DDD, somente dígitos.
  whatsappDisplay: "(16)99626-2395", // Texto visível informado pelo proprietário.
  profilePhoto: "", // URL ou caminho público da sua foto de perfil.
  publicOrigin: "", // Preencha depois de definir o domínio público do site.
  heroImage: "/manus-storage/async-images/v7uNS63VSoUVZZm0DViAvh/image-1.webp",
};

export const navigation = [
  ["inicio", "Início"],
  ["sobre", "Sobre mim"],
  ["servicos", "Serviços"],
  ["portfolio", "Portfólio"],
  ["tecnologias", "Tecnologias"],
  ["contato", "Contato"],
] as const;
