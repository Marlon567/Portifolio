import { useRef, useState } from "react";
import * as Dialog from "@radix-ui/react-dialog";
import { ArrowRight, ArrowUpRight, Sparkles, X } from "lucide-react";

type Category = "Negócios locais" | "Institucionais" | "Landing pages";
type Filter = "Todos" | Category;

type Project = {
  id: string;
  name: string;
  brand: string;
  category: Category;
  description: string;
  scope: string;
  headline: string;
  subline: string;
  eyebrow: string;
  navItems: string[];
  navAction: string;
  primaryLabel: string;
  secondaryLabel: string;
  mark: string;
  image: string;
  imageAlt: string;
  theme: string;
  techs: string[];
  quoteService: string;
};

const filters: Filter[] = [
  "Todos",
  "Negócios locais",
  "Institucionais",
  "Landing pages",
];

const projects: Project[] = [
  {
    id: "mesa-brasa",
    name: "Mesa & Brasa",
    brand: "MESA & BRASA",
    category: "Negócios locais",
    description:
      "Um conceito digital acolhedor para apresentar a cozinha, o ambiente e os caminhos para reservar uma mesa.",
    scope:
      "Página inicial com destaque para a proposta gastronômica, introdução ao espaço, chamada para reservas e pontos de descoberta do cardápio.",
    headline: "Sabor que reúne.",
    subline: "Encontros à mesa, bons momentos à brasa.",
    eyebrow: "COZINHA DE ENCONTROS",
    navItems: ["Nossa cozinha", "Cardápio", "O espaço"],
    navAction: "Reservas",
    primaryLabel: "Conheça a casa",
    secondaryLabel: "Ver cardápio",
    mark: "M",
    image: "/manus-storage/async-images/saODhHpzZXUxw7dDJ8sfOo/image-1.webp",
    imageAlt:
      "Fotografia de conceito para a página do restaurante Mesa & Brasa.",
    theme: "mesa",
    techs: ["React", "Tailwind", "JavaScript"],
    quoteService: "Site para restaurante",
  },
  {
    id: "distrito-barber",
    name: "Distrito Barber",
    brand: "DISTRITO",
    category: "Negócios locais",
    description:
      "Uma vitrine urbana de barbearia, com identidade marcante e informações essenciais fáceis de encontrar.",
    scope:
      "Página inicial com apresentação da barbearia, serviços em evidência, informações de visita e chamadas para agendamento.",
    headline: "Seu estilo. Sua assinatura.",
    subline: "Precisão no corte. Atitude em cada detalhe.",
    eyebrow: "BARBEARIA CONTEMPORÂNEA",
    navItems: ["A casa", "Serviços", "Barbeiros"],
    navAction: "Agendar",
    primaryLabel: "Encontre seu corte",
    secondaryLabel: "Nossos serviços",
    mark: "D",
    image: "/manus-storage/async-images/saODhHpzZXUxw7dDJ8sfOo/image-2.webp",
    imageAlt:
      "Fotografia de conceito para o site da barbearia Distrito Barber.",
    theme: "distrito",
    techs: ["HTML5", "CSS3", "JavaScript"],
    quoteService: "Site para barbearia ou salão",
  },
  {
    id: "pulse-training",
    name: "Pulse Training",
    brand: "PULSE",
    category: "Negócios locais",
    description:
      "Um conceito energético para apresentar treinos, estrutura e planos de uma academia de forma direta.",
    scope:
      "Página inicial com mensagem de motivação, apresentação dos treinos, diferenciais da academia e orientação para conhecer os planos.",
    headline: "Sua melhor versão começa aqui.",
    subline: "Treino com propósito. Evolução no seu ritmo.",
    eyebrow: "MOVIMENTO QUE TRANSFORMA",
    navItems: ["Treinos", "Estrutura", "Planos"],
    navAction: "Começar",
    primaryLabel: "Explore os treinos",
    secondaryLabel: "Conheça a Pulse",
    mark: "P",
    image: "/manus-storage/async-images/saODhHpzZXUxw7dDJ8sfOo/image-3.webp",
    imageAlt:
      "Fotografia de conceito para a página da academia Pulse Training.",
    theme: "pulse",
    techs: ["React", "CSS3", "Tailwind"],
    quoteService: "Site para academia",
  },
  {
    id: "sorriso-clinica",
    name: "Sorriso Clínica",
    brand: "sorriso",
    category: "Institucionais",
    description:
      "Uma proposta leve e clara para comunicar cuidado odontológico e orientar pacientes pelos próximos passos.",
    scope:
      "Página institucional com apresentação da clínica, tratamentos, equipe, informações para pacientes e um caminho de contato em destaque.",
    headline: "Um novo motivo para sorrir.",
    subline: "Cuidado próximo, pensado para você.",
    eyebrow: "CUIDADO QUE ACOLHE",
    navItems: ["A clínica", "Tratamentos", "Equipe"],
    navAction: "Agendar consulta",
    primaryLabel: "Conheça a clínica",
    secondaryLabel: "Nossos tratamentos",
    mark: "+",
    image: "/manus-storage/async-images/saODhHpzZXUxw7dDJ8sfOo/image-4.webp",
    imageAlt:
      "Fotografia de conceito para o site institucional Sorriso Clínica.",
    theme: "sorriso",
    techs: ["HTML5", "React", "CSS3"],
    quoteService: "Site institucional",
  },
  {
    id: "habitat-imoveis",
    name: "Habitat Imóveis",
    brand: "HABITAT",
    category: "Institucionais",
    description:
      "Uma presença elegante para uma marca imobiliária fictícia, equilibrando inspiração e informação.",
    scope:
      "Página institucional com apresentação da marca, seleção visual de imóveis, contexto de atendimento e convite para conversar.",
    headline: "Seu próximo capítulo mora aqui.",
    subline: "Espaços para viver novas histórias.",
    eyebrow: "IMÓVEIS COM OUTRO OLHAR",
    navItems: ["Imóveis", "Sobre nós", "Contato"],
    navAction: "Fale conosco",
    primaryLabel: "Descubra possibilidades",
    secondaryLabel: "Sobre a Habitat",
    mark: "H",
    image: "/manus-storage/async-images/saODhHpzZXUxw7dDJ8sfOo/image-5.webp",
    imageAlt:
      "Fotografia de conceito para o site institucional Habitat Imóveis.",
    theme: "habitat",
    techs: ["React", "JavaScript", "Tailwind"],
    quoteService: "Site institucional",
  },
  {
    id: "aura-sound",
    name: "Aura Sound",
    brand: "AURA SOUND",
    category: "Landing pages",
    description:
      "Uma landing page de vendas conceitual para um produto de áudio, com benefícios em destaque e uma chamada de compra direta.",
    scope:
      "Landing page de vendas com hero de produto, apresentação da oferta, benefícios e CTA de compra. As chamadas são decorativas neste conceito; não há checkout ou venda real.",
    headline: "Sinta cada detalhe.",
    subline: "Uma experiência sonora que envolve.",
    eyebrow: "SOM EM OUTRA DIMENSÃO",
    navItems: ["Experiência", "Tecnologia", "Detalhes"],
    navAction: "Comprar",
    primaryLabel: "Quero meu Aura Sound",
    secondaryLabel: "Ver detalhes",
    mark: "A",
    image: "/manus-storage/async-images/Q7nFkbFGGHOOvRtlgibNwI/image-1.webp",
    imageAlt: "Fotografia de conceito para a landing page de áudio Aura Sound.",
    theme: "aura",
    techs: ["HTML5", "CSS3", "Tailwind"],
    quoteService: "Landing page",
  },
];

function ProjectMockup({
  project,
  large = false,
}: {
  project: Project;
  large?: boolean;
}) {
  return (
    <div
      className={`pg-mockup pg-theme-${project.theme}${large ? " pg-mockup--large" : " pg-mockup--compact"}`}
      aria-label={`Prévia visual conceitual de ${project.name}`}
    >
      <div className="pg-browser-bar" aria-hidden="true">
        <span className="pg-browser-dots">
          <i />
          <i />
          <i />
        </span>
        <span className="pg-browser-caption">prévia de conceito</span>
        <span className="pg-browser-mark">
          <Sparkles size={12} strokeWidth={1.8} />
        </span>
      </div>

      <div className="pg-site-frame">
        <div className="pg-site-nav">
          <span className="pg-site-brand">
            <span className="pg-brand-mark" aria-hidden="true">
              {project.mark}
            </span>
            <span>{project.brand}</span>
          </span>
          <span className="pg-site-links" aria-hidden="true">
            {project.navItems.map(item => (
              <span key={item}>{item}</span>
            ))}
          </span>
          <span className="pg-site-nav-action" aria-hidden="true">
            {project.navAction}
          </span>
        </div>

        <div className="pg-hero">
          <img
            className="pg-hero-image"
            src={project.image}
            alt={project.imageAlt}
            width={1440}
            height={900}
            loading="lazy"
            decoding="async"
          />
          <span className="pg-hero-shade" aria-hidden="true" />
          <div className="pg-hero-copy">
            <span className="pg-hero-eyebrow">{project.eyebrow}</span>
            <h3>{project.headline}</h3>
            <p>{project.subline}</p>
            <div className="pg-hero-actions" aria-hidden="true">
              <span className="pg-hero-primary">
                {project.primaryLabel}
                <ArrowUpRight size={14} />
              </span>
              <span className="pg-hero-secondary">
                {project.secondaryLabel}
              </span>
            </div>
          </div>
          <span className="pg-hero-index" aria-hidden="true">
            01 / 03
          </span>
        </div>
      </div>
    </div>
  );
}

export default function ProjectGallery({
  onQuote,
}: {
  onQuote: (service: string) => void;
}) {
  const [activeFilter, setActiveFilter] = useState<Filter>("Todos");
  const [activeProject, setActiveProject] = useState<Project | null>(null);
  const openerRef = useRef<HTMLButtonElement | null>(null);
  const quoteTransitionRef = useRef(false);
  const visibleProjects =
    activeFilter === "Todos"
      ? projects
      : projects.filter(project => project.category === activeFilter);

  const requestQuote = () => {
    if (!activeProject) return;
    const service = activeProject.quoteService;
    quoteTransitionRef.current = true;
    setActiveProject(null);
    requestAnimationFrame(() => {
      onQuote(service);
      document
        .querySelector<HTMLInputElement>('#contato input[name="name"]')
        ?.focus({ preventScroll: true });
    });
  };

  return (
    <Dialog.Root
      open={activeProject !== null}
      onOpenChange={open => {
        if (!open) setActiveProject(null);
      }}
    >
      <section
        className="pg-section"
        aria-label="Galeria de projetos demonstrativos"
      >
        <div
          className="pg-filters"
          role="group"
          aria-label="Filtrar projetos por categoria"
        >
          {filters.map(filter => (
            <button
              key={filter}
              type="button"
              className={`pg-filter${activeFilter === filter ? " pg-filter--active" : ""}`}
              aria-pressed={activeFilter === filter}
              onClick={() => setActiveFilter(filter)}
            >
              {filter}
              {activeFilter === filter && (
                <span className="pg-filter-count">
                  {visibleProjects.length}
                </span>
              )}
            </button>
          ))}
        </div>

        <div className="pg-grid" aria-live="polite">
          {visibleProjects.map((project, index) => (
            <article
              className="pg-card"
              key={project.id}
              style={{ "--pg-card-index": index } as React.CSSProperties}
            >
              <button
                type="button"
                className="pg-card-trigger"
                aria-label={`Visualizar projeto: ${project.name}`}
                aria-haspopup="dialog"
                onClick={event => {
                  openerRef.current = event.currentTarget;
                  quoteTransitionRef.current = false;
                  setActiveProject(project);
                }}
              >
                <span className="pg-card-visual">
                  <ProjectMockup project={project} />
                  <span className="pg-card-category">{project.category}</span>
                </span>
                <span className="pg-card-content">
                  <span className="pg-card-heading-row">
                    <span className="pg-card-title">{project.name}</span>
                    <ArrowUpRight
                      className="pg-card-corner"
                      size={18}
                      strokeWidth={1.7}
                      aria-hidden="true"
                    />
                  </span>
                  <span className="pg-card-description">
                    {project.description}
                  </span>
                  <span
                    className="pg-tech-list"
                    aria-label={`Tecnologias: ${project.techs.join(", ")}`}
                  >
                    {project.techs.map(tech => (
                      <span className="pg-tech" key={tech}>
                        {tech}
                      </span>
                    ))}
                  </span>
                  <span className="pg-card-link">
                    Visualizar projeto{" "}
                    <ArrowRight size={16} aria-hidden="true" />
                  </span>
                </span>
              </button>
            </article>
          ))}
        </div>
      </section>

      {activeProject && (
        <Dialog.Portal>
          <Dialog.Overlay className="pg-dialog-overlay" />
          <Dialog.Content
            className="pg-dialog-content"
            onCloseAutoFocus={event => {
              event.preventDefault();
              if (!quoteTransitionRef.current)
                openerRef.current?.focus({ preventScroll: true });
            }}
          >
            <div className="pg-dialog-header">
              <div className="pg-dialog-heading">
                <span className="pg-concept-label">
                  <Sparkles size={14} /> Projeto-conceito • demonstração visual
                </span>
                <Dialog.Title className="pg-dialog-title">
                  {activeProject.name}
                </Dialog.Title>
                <Dialog.Description className="pg-dialog-description">
                  {activeProject.description}
                </Dialog.Description>
              </div>
              <Dialog.Close asChild>
                <button
                  className="pg-dialog-close"
                  type="button"
                  aria-label="Fechar detalhes do projeto"
                >
                  <X size={20} />
                </button>
              </Dialog.Close>
            </div>

            <div className="pg-dialog-preview">
              <ProjectMockup project={activeProject} large />
            </div>

            <div className="pg-dialog-details">
              <div className="pg-detail-block">
                <span className="pg-detail-label">SOBRE O CONCEITO</span>
                <p>{activeProject.description}</p>
              </div>
              <div className="pg-detail-block">
                <span className="pg-detail-label">ESCOPO</span>
                <p>{activeProject.scope}</p>
              </div>
              <div className="pg-detail-block">
                <span className="pg-detail-label">STACK PROPOSTA</span>
                <div className="pg-tech-list pg-tech-list--modal">
                  {activeProject.techs.map(tech => (
                    <span className="pg-tech" key={tech}>
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="pg-dialog-footer">
              <p>
                Gostou da direção visual? Vamos conversar sobre algo feito para
                sua marca.
              </p>
              <button
                className="pg-quote-button"
                type="button"
                onClick={requestQuote}
              >
                Quero um projeto assim <ArrowRight size={17} />
              </button>
            </div>
          </Dialog.Content>
        </Dialog.Portal>
      )}
    </Dialog.Root>
  );
}
