import { useEffect, useState, type FormEvent } from "react";
import {
  ArrowUpRight,
  Check,
  Copy,
  Download,
  Mail,
  MessageCircle,
} from "lucide-react";
import { site } from "../../lib/site";

export const serviceNames = [
  "Site institucional",
  "Landing page",
  "Site para restaurante",
  "Site para barbearia ou salão",
  "Site para academia",
  "Portfólio profissional",
  "Redesign de site",
  "Manutenção e otimização",
  "Quero uma orientação",
];

export default function ContactForm({
  selectedService,
}: {
  selectedService: string;
}) {
  const [service, setService] = useState(selectedService);
  const [briefing, setBriefing] = useState("");
  const [copied, setCopied] = useState(false);
  const [copyError, setCopyError] = useState(false);
  useEffect(() => {
    setService(selectedService);
    setBriefing("");
  }, [selectedService]);

  function prepare(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const nameField = event.currentTarget.elements.namedItem(
      "name"
    ) as HTMLInputElement;
    const messageField = event.currentTarget.elements.namedItem(
      "message"
    ) as HTMLTextAreaElement;
    nameField.setCustomValidity(
      nameField.value.trim().length < 2
        ? "Informe seu nome com pelo menos 2 caracteres."
        : ""
    );
    messageField.setCustomValidity(
      messageField.value.trim().length < 15
        ? "Conte um pouco mais sobre sua ideia (pelo menos 15 caracteres)."
        : ""
    );
    if (!event.currentTarget.reportValidity()) return;
    const data = new FormData(event.currentTarget);
    const text = [
      `Olá, ${site.name}! Gostaria de um orçamento para meu projeto.`,
      "",
      `Nome: ${String(data.get("name")).trim()}`,
      `E-mail: ${String(data.get("email")).trim()}`,
      `Empresa: ${String(data.get("company")).trim() || "Não informado"}`,
      `Serviço: ${service}`,
      `Prazo desejado: ${data.get("deadline")}`,
      "",
      `Sobre o projeto: ${String(data.get("message")).trim()}`,
    ].join("\n");
    setBriefing(text);
    setCopied(false);
    setCopyError(false);
  }

  async function copy() {
    try {
      await navigator.clipboard.writeText(briefing);
      setCopied(true);
      setCopyError(false);
    } catch {
      setCopyError(true);
    }
  }

  function download() {
    const url = URL.createObjectURL(
      new Blob([briefing], { type: "text/plain;charset=utf-8" })
    );
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = "briefing-meu-site.txt";
    anchor.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  const hasChannel = Boolean(site.email || site.whatsapp);
  return (
    <form
      className="quote-form"
      onSubmit={prepare}
      onChange={event => {
        setBriefing("");
        if (
          event.target instanceof HTMLInputElement ||
          event.target instanceof HTMLTextAreaElement
        )
          event.target.setCustomValidity("");
      }}
    >
      <div className="form-heading">
        <span className="step-dot">01</span>
        <div>
          <h3>Conte sobre sua ideia</h3>
          <p>Vamos dar o primeiro passo para o seu novo site.</p>
        </div>
      </div>
      <div className="form-pair">
        <label>
          Seu nome <span>*</span>
          <input
            name="name"
            autoComplete="name"
            placeholder="Como posso te chamar?"
            minLength={2}
            maxLength={100}
            required
          />
        </label>
        <label>
          E-mail <span>*</span>
          <input
            name="email"
            type="email"
            autoComplete="email"
            placeholder="voce@empresa.com.br"
            maxLength={254}
            required
          />
        </label>
      </div>
      <label>
        Empresa ou marca
        <input
          name="company"
          autoComplete="organization"
          placeholder="Nome do seu negócio (opcional)"
          maxLength={120}
        />
      </label>
      <div className="form-pair">
        <label>
          O que você precisa? <span>*</span>
          <select
            name="service"
            value={service}
            onChange={event => setService(event.target.value)}
            required
          >
            <option value="" disabled>
              Selecione um serviço
            </option>
            {serviceNames.map(name => (
              <option key={name}>{name}</option>
            ))}
          </select>
        </label>
        <label>
          Prazo desejado
          <select name="deadline" defaultValue="Sem prazo definido">
            <option>Sem prazo definido</option>
            <option>Em até 30 dias</option>
            <option>Entre 1 e 2 meses</option>
            <option>Mais de 2 meses</option>
          </select>
        </label>
      </div>
      <label>
        Um pouco sobre o projeto <span>*</span>
        <textarea
          name="message"
          placeholder="Me conte sobre o seu negócio, o que deseja no site e quais são seus objetivos."
          rows={4}
          minLength={15}
          maxLength={3000}
          required
        />
      </label>
      <label className="consent">
        <input name="consent" type="checkbox" required />
        <span>
          Autorizo o compartilhamento das informações acima para conversar sobre
          meu projeto.
        </span>
      </label>
      <button className="button button-primary form-submit" type="submit">
        Preparar meu pedido de orçamento <ArrowUpRight size={18} />
      </button>
      <p className="form-note">
        {hasChannel
          ? "Você poderá revisar o briefing antes de abrir seu canal de contato."
          : "Os dados ficam no seu navegador. Nenhuma mensagem é enviada nesta etapa."}
      </p>
      {briefing && (
        <div className="briefing-result" role="status">
          <div className="briefing-title">
            <Check size={18} />
            <strong>Seu briefing está pronto!</strong>
          </div>
          <p>
            {hasChannel
              ? "Revise sua mensagem e escolha como iniciar a conversa."
              : "O envio está aguardando a configuração de e-mail ou WhatsApp do desenvolvedor. Por enquanto, copie ou baixe seu pedido."}
          </p>
          <textarea
            aria-label="Briefing preparado para revisão"
            value={briefing}
            readOnly
            rows={8}
          />
          <div className="briefing-actions">
            {site.whatsapp && (
              <a
                className="button button-primary"
                href={`https://wa.me/${site.whatsapp}?text=${encodeURIComponent(briefing)}`}
                target="_blank"
                rel="noopener noreferrer"
              >
                <MessageCircle size={16} /> Abrir WhatsApp
              </a>
            )}
            {site.email && (
              <a
                className="button button-primary"
                href={`mailto:${site.email}?subject=${encodeURIComponent("Orçamento para desenvolvimento de site")}&body=${encodeURIComponent(briefing)}`}
              >
                <Mail size={16} /> Abrir e-mail
              </a>
            )}
            <button
              className="button button-outline"
              type="button"
              onClick={copy}
            >
              {copied ? <Check size={16} /> : <Copy size={16} />}
              {copied ? "Copiado" : "Copiar briefing"}
            </button>
            <button
              className="button button-outline"
              type="button"
              onClick={download}
            >
              <Download size={16} /> Baixar .txt
            </button>
          </div>
          {copyError && (
            <p className="copy-error">
              Não foi possível copiar automaticamente. Selecione o texto acima
              ou baixe o arquivo.
            </p>
          )}
        </div>
      )}
    </form>
  );
}
