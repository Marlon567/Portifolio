import { describe, expect, it } from "vitest";
import { renderToString } from "react-dom/server";
import App from "./App";

const html = renderToString(<App />);

describe("portfólio público", () => {
  it("apresenta o título, o subtítulo e as chamadas principais", () => {
    expect(html).toContain("Transformo ideias");
    expect(html).toContain("experiências");
    expect(html).toContain("Desenvolvo sites modernos, rápidos e estratégicos");
    expect(html).toContain("Conhecer meus projetos");
    expect(html).toContain("Solicitar um orçamento");
    expect((html.match(/<h1>/g) || []).length).toBe(1);
  });

  it("mantém os seis destinos de navegação disponíveis no HTML inicial", () => {
    for (const id of [
      "inicio",
      "sobre",
      "servicos",
      "portfolio",
      "tecnologias",
      "contato",
    ]) {
      expect(html).toContain(`href="#${id}"`);
      expect(html).toContain(`id="${id}"`);
    }
  });

  it("inclui os oito serviços e a apresentação pessoal", () => {
    for (const title of [
      "Sites institucionais",
      "Landing pages",
      "Sites para restaurantes",
      "Barbearias e salões",
      "Sites para academias",
      "Portfólios profissionais",
      "Redesign de sites",
      "Manutenção e otimização",
    ])
      expect(html).toContain(title);
    expect(html).toContain("Sou desenvolvedor web apaixonado por tecnologia");
    expect(html).toContain("Espaço para sua foto de perfil");
  });

  it("identifica os seis projetos como conceitos e oferece visualização", () => {
    for (const name of [
      "Mesa &amp; Brasa",
      "Distrito Barber",
      "Pulse Training",
      "Sorriso Clínica",
      "Habitat Imóveis",
      "Aura Sound",
    ])
      expect(html).toContain(name);
    expect((html.match(/aria-label="Visualizar projeto:/g) || []).length).toBe(
      6
    );
    expect(html).toContain("Projetos-conceito para demonstração visual");
    expect(html).toContain("Não representam clientes ou resultados reais");
  });

  it("oferece filtros, tecnologias e formulário validável", () => {
    for (const filter of [
      "Todos",
      "Negócios locais",
      "Institucionais",
      "Landing pages",
    ])
      expect(html).toContain(filter);
    for (const tech of [
      "HTML5",
      "CSS3",
      "JavaScript",
      "React",
      "TypeScript",
      "Tailwind CSS",
    ])
      expect(html).toContain(tech);
    expect(html).toContain('type="email"');
    expect(html).toContain('minLength="15"');
    expect(html).toContain('type="checkbox"');
  });

  it("exibe os contatos informados e normaliza apenas o destino do WhatsApp", () => {
    expect(html).toContain("marlonprado2001@gmail.com");
    expect(html).toContain("(16)99626-2395");
    expect(html).toContain('href="mailto:marlonprado2001@gmail.com"');
    expect(html).toContain('href="https://wa.me/5516996262395"');
    expect(html).not.toContain("5516996262395</b>");
    expect(html).toContain("E-MAIL PROFISSIONAL");
    expect(html).not.toContain("Contato a configurar");
    expect(html).not.toContain("Número a configurar");
    expect(html).toContain("Você poderá revisar o briefing antes de abrir seu canal de contato.");
  });
});
